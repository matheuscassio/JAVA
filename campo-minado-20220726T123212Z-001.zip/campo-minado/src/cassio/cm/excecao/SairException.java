package cassio.cm.excecao;

public class SairException extends RuntimeException{

	private static final long serialVersionUID = 1;

}
